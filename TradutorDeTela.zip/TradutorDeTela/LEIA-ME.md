# Tradutor de Tela (Android)

Traduz para português do Brasil qualquer texto em outro idioma que aparecer na tela:
apps, navegador, chats **e também texto dentro de imagens, vídeos e jogos (OCR)**.
Quando o texto se mexe (rolagem, legenda, texto de jogo), a tradução acompanha.

## Gerar o app
1. Instale o Android Studio (developer.android.com/studio) e use File > Open para abrir esta pasta.
2. Espere o Gradle sincronizar (precisa de internet na primeira vez).
3. No celular, ative Opções do desenvolvedor > Depuração USB, conecte o cabo e clique em Run (▶).
   Ou use Build > Build APK(s) e instale app/build/outputs/apk/debug/app-debug.apk.

## Usar
1. Abra o app e toque em Iniciar.
2. Na primeira vez, o Android pede para ativar o serviço em Acessibilidade > Tradutor de Tela.
   Se aparecer "configuração restrita": Config. > Apps > Tradutor de Tela > ⋮ > Permitir configurações restritas.
3. Ao voltar para o app, ele começa sozinho, vai para a tela inicial e traduz em segundo plano.
4. Para parar, abra o app e toque em Parar.

Na tela do app:
- **Ler imagens, vídeos e jogos (OCR)**: liga/desliga a leitura por captura de tela.
- **Cobrir o texto original (pode piscar)**: desligado por padrão. Desligado, a tradução aparece ao lado
  (acima ou abaixo) do texto original, sem piscar. Ligado, a tradução cobre o texto original, mas as caixas
  somem por um instante a cada captura para o OCR enxergar o original (isso pisca).
- **Idiomas extras do OCR**: o alfabeto latino (inglês, espanhol, francês, alemão...) sempre funciona.
  Marque japonês, chinês, coreano ou hindi se precisar. Cada alfabeto extra deixa a leitura um pouco mais lenta.

## Como funciona
- A cada ~0,4 s o app tira uma captura da tela, lê o texto com OCR (ML Kit) e também lê os textos
  que os apps expõem para a acessibilidade (esses são mais precisos e têm prioridade).
- Um rastreador liga cada texto ao que foi visto na leitura anterior. Se o texto mudou de lugar,
  a caixa da tradução desliza até ele e, entre uma leitura e outra, continua andando na mesma velocidade.
- No OCR, a tradução fica ao lado do texto (o original continua visível e é acompanhado sem piscar).
  As caixas do próprio app são apagadas da captura antes do OCR, para ele não ler a tradução.
- Se não houver espaço livre ao lado (listas apertadas), a caixa cobre o texto e, de vez em quando
  (a cada ~3 s), some por um instante para conferir se o texto ainda está lá.
- A caixa da tradução copia a cor de fundo ao redor do texto original.
- Se a tela está parada, o app lê bem menos vezes (economiza bateria).
- Tudo é feito no aparelho. Na primeira vez que um idioma aparece, o app baixa o pacote de tradução
  dele (cerca de 30 MB). São 59 idiomas suportados.

## Limitações
- Só Android 11 ou mais novo (a captura de tela por acessibilidade só existe a partir dele).
- Apps que bloqueiam captura de tela (bancos, alguns serviços de vídeo com DRM) saem pretos: o OCR não
  lê nada neles, mas textos que o app expõe para a acessibilidade continuam sendo traduzidos.
- O Android limita a ~3 capturas por segundo. Em movimento muito rápido a tradução pode atrasar um pouco.
- OCR de fontes muito estilizadas, letras pequenas ou fundo poluído pode errar.
- Esta versão não foi compilada nem testada em aparelho real: se o Gradle ou o app apresentar erro,
  copie a mensagem para ajustar.
