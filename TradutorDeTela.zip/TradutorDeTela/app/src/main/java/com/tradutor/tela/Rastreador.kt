package com.tradutor.tela

import android.graphics.Rect
import android.graphics.RectF
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

/** Um texto encontrado na tela (por acessibilidade ou por OCR). */
data class Deteccao(
    val rect: Rect,
    val texto: String,
    val fundo: Int = 0,
    val corTexto: Int = 0,
    val ocr: Boolean = false
)

/** Um texto que o app está acompanhando entre uma leitura e outra. */
class Faixa(
    val id: Long,
    var texto: String,
    var ocr: Boolean,
    var rect: RectF,
    var fundo: Int,
    var corTexto: Int,
    var visto: Long
) {
    /** Velocidade em px/s, usada para prever onde o texto está entre duas leituras. */
    var vx = 0f
    var vy = 0f

    /** Última tradução conhecida; continua aparecendo enquanto a nova não chega. */
    var traducao: String? = null

    /** true quando a caixa da tradução está em cima do texto original (não dá para vê-lo). */
    var cobrindo = false
}

/** Quanto de [a] (0 a 1) está dentro de [b]. */
fun cobertura(a: RectF, b: RectF): Float {
    val w = min(a.right, b.right) - max(a.left, b.left)
    val h = min(a.bottom, b.bottom) - max(a.top, b.top)
    if (w <= 0f || h <= 0f) return 0f
    val area = a.width() * a.height()
    return if (area <= 0f) 0f else (w * h) / area
}

/**
 * Reconhece, a cada leitura, os mesmos textos da leitura anterior (mesmo que tenham
 * mudado de lugar) para a tradução acompanhar o texto em vez de sumir e reaparecer.
 */
class Rastreador {

    companion object {
        private const val SIM_MIN = 0.72f
        private const val V_MAX = 4000f
        private const val MAX_FAIXAS = 80
        private const val CHARS_COMPARADOS = 40
    }

    private val faixas = ArrayList<Faixa>()
    private var proximoId = 1L

    val lista: List<Faixa> get() = faixas

    fun limpar() {
        faixas.clear()
    }

    /** Tela parada: nada mudou, então tudo continua onde estava. */
    fun manterVivas(agora: Long) {
        for (f in faixas) {
            f.visto = agora
            f.vx = 0f
            f.vy = 0f
        }
    }

    private class Par(val d: Int, val f: Int, val sim: Float, val dist: Float)

    fun atualizar(dets: List<Deteccao>, agora: Long, tolerancia: Long, limpa: Boolean) {
        val usadaD = BooleanArray(dets.size)
        val usadaF = BooleanArray(faixas.size)

        // 1) Mesmo texto (ou quase): é o mesmo item, só mudou de lugar.
        val pares = ArrayList<Par>()
        for (i in dets.indices) {
            for (j in faixas.indices) {
                val s = similaridade(dets[i].texto, faixas[j].texto)
                if (s >= SIM_MIN) {
                    pares.add(Par(i, j, s, distancia(RectF(dets[i].rect), faixas[j].rect)))
                }
            }
        }
        pares.sortWith(compareByDescending<Par> { (it.sim * 10f).toInt() }.thenBy { it.dist })
        for (p in pares) {
            if (usadaD[p.d] || usadaF[p.f]) continue
            usadaD[p.d] = true
            usadaF[p.f] = true
            aplicar(faixas[p.f], dets[p.d], agora)
        }

        // 2) Texto diferente no mesmo lugar (legenda que trocou, fala de jogo...).
        for (i in dets.indices) {
            if (usadaD[i]) continue
            val r = RectF(dets[i].rect)
            var melhor = -1
            var melhorCob = 0.6f
            for (j in usadaF.indices) {
                if (usadaF[j]) continue
                val cob = max(cobertura(r, faixas[j].rect), cobertura(faixas[j].rect, r))
                if (cob > melhorCob) {
                    melhorCob = cob
                    melhor = j
                }
            }
            if (melhor >= 0) {
                usadaD[i] = true
                usadaF[melhor] = true
                aplicar(faixas[melhor], dets[i], agora)
            }
        }

        // 3) O que sobrou é novo.
        for (i in dets.indices) {
            if (usadaD[i]) continue
            val d = dets[i]
            faixas.add(Faixa(proximoId++, d.texto, d.ocr, RectF(d.rect), d.fundo, d.corTexto, agora))
        }

        // 4) Some o que não é visto há tempo demais.
        // Texto escondido sob a própria caixa só pode ser conferido numa leitura "limpa".
        faixas.removeAll { agora - it.visto > tolerancia && !(it.cobrindo && !limpa) }
        if (faixas.size > MAX_FAIXAS) {
            faixas.sortByDescending { it.visto }
            while (faixas.size > MAX_FAIXAS) faixas.removeAt(faixas.size - 1)
        }
    }

    private fun aplicar(f: Faixa, d: Deteccao, agora: Long) {
        val novo = RectF(d.rect)
        val dt = (agora - f.visto).coerceAtLeast(1L) / 1000f
        val dx = novo.centerX() - f.rect.centerX()
        val dy = novo.centerY() - f.rect.centerY()
        val tol = max(4f, f.rect.height() * 0.25f)

        if (abs(dx) < tol && abs(dy) < tol) {
            // Parado: mantém o retângulo antigo para a caixa não tremer.
            f.vx = 0f
            f.vy = 0f
            if (abs(novo.width() - f.rect.width()) > tol * 2 ||
                abs(novo.height() - f.rect.height()) > tol
            ) {
                f.rect = novo
            }
        } else {
            if (dt > 1.2f) {
                f.vx = 0f
                f.vy = 0f
            } else {
                f.vx = (f.vx * 0.35f + (dx / dt) * 0.65f).coerceIn(-V_MAX, V_MAX)
                f.vy = (f.vy * 0.35f + (dy / dt) * 0.65f).coerceIn(-V_MAX, V_MAX)
            }
            f.rect = novo
        }

        f.visto = agora
        f.fundo = d.fundo
        f.corTexto = d.corTexto
        f.ocr = d.ocr
        if (f.texto != d.texto) f.texto = d.texto
    }

    private fun distancia(a: RectF, b: RectF): Float =
        hypot(a.centerX() - b.centerX(), a.centerY() - b.centerY())

    private fun normalizar(s: String): String =
        s.lowercase().filter { it.isLetterOrDigit() }.take(CHARS_COMPARADOS)

    private fun similaridade(a: String, b: String): Float {
        val x = normalizar(a)
        val y = normalizar(b)
        if (x.isEmpty() || y.isEmpty()) return 0f
        if (x == y) return 1f
        val maior = max(x.length, y.length)
        if (abs(x.length - y.length) > maior * 0.4f) return 0f
        return 1f - levenshtein(x, y).toFloat() / maior
    }

    private fun levenshtein(a: String, b: String): Int {
        var ant = IntArray(b.length + 1) { it }
        var atual = IntArray(b.length + 1)
        for (i in 1..a.length) {
            atual[0] = i
            for (j in 1..b.length) {
                val custo = if (a[i - 1] == b[j - 1]) 0 else 1
                atual[j] = min(min(atual[j - 1] + 1, ant[j] + 1), ant[j - 1] + custo)
            }
            val tmp = ant
            ant = atual
            atual = tmp
        }
        return ant[b.length]
    }
}
