package com.tradutor.tela

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityService.ScreenshotResult
import android.accessibilityservice.AccessibilityService.TakeScreenshotCallback
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.RectF
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.view.Display
import android.view.Gravity
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import java.util.concurrent.Executors

/**
 * Serviço de acessibilidade. A cada ciclo:
 *  1. tira uma captura da tela (para o OCR ler imagens, vídeos e jogos);
 *  2. lê também os textos "de verdade" da tela (acessibilidade), que são mais precisos;
 *  3. o Rastreador liga cada texto ao que foi visto no ciclo anterior (mesmo que tenha se mexido);
 *  4. traduz e desenha a tradução por cima, acompanhando o movimento.
 */
class TradutorService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: TradutorService? = null
            private set

        val rodando: Boolean
            get() = instance?.ativo == true

        const val PREFS = "tradutor"
        const val CHAVE_ATIVO = "ativo"
        const val CHAVE_OCR = "ocr"
        const val CHAVE_COBRIR = "cobrir"
        const val CHAVE_IDIOMAS = "ocr_idiomas"

        private const val MAX_NOS = 1500
        private const val MAX_NIVEL = 50
        private const val MAX_CHARS = 4000

        // O Android só deixa tirar uma captura a cada ~333 ms.
        private const val INTERVALO_MIN = 380L
        private const val INTERVALO_MAX = 2000L
        private const val TOLERANCIA_MIN = 900L

        // Só usado quando há caixa em cima do texto original: de tempos em tempos as caixas
        // somem por um instante para o OCR conferir se o texto ainda está lá.
        private const val ATRASO_ESCONDER = 50L
        private const val INTERVALO_LIMPA = 3000L
    }

    @Volatile
    private var ativo = false

    private val handler = Handler(Looper.getMainLooper())
    private val worker = Executors.newSingleThreadExecutor()
    private var motor: TradutorMotor? = null
    private var leitor: LeitorOcr? = null
    private var overlay: OverlayView? = null
    private val rastreador = Rastreador()

    @Volatile
    private var usarOcr = true

    @Volatile
    private var cobrir = false

    // true quando a captura do ciclo foi feita sem as caixas de tradução na tela.
    private var cicloLimpo = true
    private var ultimaLimpa = 0L

    private var agendado = false
    private var emCiclo = false
    private var inicioCiclo = 0L
    private var intervalo = INTERVALO_MIN
    private var ultimoPacote: String? = null

    private val rotinaCiclo = Runnable {
        agendado = false
        ciclo()
    }
    private val rotinaRender = Runnable { renderizar() }

    // Se uma captura se perder no caminho, o ciclo não pode ficar preso para sempre.
    private val rotinaVigia = Runnable {
        if (ativo && emCiclo) {
            emCiclo = false
            overlay?.alpha = 1f
            agendar(INTERVALO_MIN, true)
        }
    }

    // ---------------------------------------------------------------- ciclo de vida

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        // Se o Android reiniciou o serviço, retoma de onde parou.
        val salvo = getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(CHAVE_ATIVO, false)
        if (salvo) iniciar()
    }

    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        parar()
        instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        parar()
        instance = null
        worker.shutdownNow()
        motor?.fechar()
        motor = null
        super.onDestroy()
    }

    // ---------------------------------------------------------------- botões do app

    fun iniciar() {
        if (ativo) return
        ativo = true
        salvar(true)
        if (motor == null) motor = TradutorMotor()
        if (leitor == null) leitor = LeitorOcr()
        recarregarConfig()
        mostrarOverlay()
        agendar(0L, true)
    }

    fun parar() {
        ativo = false
        salvar(false)
        handler.removeCallbacks(rotinaCiclo)
        handler.removeCallbacks(rotinaRender)
        handler.removeCallbacks(rotinaVigia)
        agendado = false
        emCiclo = false
        rastreador.limpar()
        removerOverlay()
        // Libera a memória dos modelos de OCR.
        val l = leitor
        leitor = null
        if (l != null) {
            try {
                worker.execute { l.fechar() }
            } catch (e: Exception) {
                l.fechar()
            }
        }
    }

    /** Lê as opções salvas pelo app (OCR ligado/desligado e alfabetos extras). */
    fun recarregarConfig() {
        val p = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        usarOcr = p.getBoolean(CHAVE_OCR, true)
        cobrir = p.getBoolean(CHAVE_COBRIR, false)
        val idiomas: Set<String> = (p.getStringSet(CHAVE_IDIOMAS, emptySet()) ?: emptySet()).toSet()
        if (leitor == null && ativo) leitor = LeitorOcr()
        val l = leitor
        if (l != null) {
            try {
                worker.execute { l.configurar(idiomas); l.esquecer() }
            } catch (e: Exception) {
                // serviço encerrando
            }
        }
        rastreador.limpar()
        overlay?.definir(emptyList())
    }

    private fun salvar(valor: Boolean) {
        getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putBoolean(CHAVE_ATIVO, valor).apply()
    }

    // ---------------------------------------------------------------- eventos da tela

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (!ativo || event == null) return
        val pacote = event.packageName?.toString()
        if (pacote == packageName) return

        when (event.eventType) {
            AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED -> {
                // Outro app: as traduções antigas não valem mais. (Dentro do mesmo app nada some.)
                if (pacote != ultimoPacote) {
                    ultimoPacote = pacote
                    rastreador.limpar()
                    overlay?.definir(emptyList())
                    leitor?.esquecer()
                }
                intervalo = INTERVALO_MIN
                agendar(250L, true)
            }
            AccessibilityEvent.TYPE_VIEW_SCROLLED -> {
                // Rolagem: lê de novo logo, e a tradução vai junto com o texto.
                intervalo = INTERVALO_MIN
                agendar(0L, true)
            }
            else -> {}
        }
    }

    private fun agendar(atraso: Long, reiniciar: Boolean = false) {
        if (!ativo) return
        if (agendado) {
            if (!reiniciar) return
            handler.removeCallbacks(rotinaCiclo)
        }
        agendado = true
        handler.postDelayed(rotinaCiclo, atraso)
    }

    // ---------------------------------------------------------------- um ciclo de leitura

    private fun ciclo() {
        if (!ativo || emCiclo) return

        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        if (!pm.isInteractive) {
            agendar(3000L)
            return
        }

        emCiclo = true
        inicioCiclo = SystemClock.uptimeMillis()
        handler.removeCallbacks(rotinaVigia)
        handler.postDelayed(rotinaVigia, 6000L)

        if (!usarOcr) {
            lerSomenteNos(false)
            return
        }

        // Por padrão a captura é feita COM as caixas na tela (sem piscar): as caixas são apagadas
        // da imagem antes do OCR, e a tradução fica ao lado do texto original, que continua visível.
        // Só quando alguma caixa cobre o texto original (modo "cobrir" ou sem espaço livre) as
        // caixas somem rapidamente de vez em quando para o OCR conferir o texto.
        val agora = SystemClock.uptimeMillis()
        val temCaixas = overlay?.temCaixas() == true
        val temCobertos = rastreador.lista.any { it.cobrindo }
        val precisaLimpa = temCaixas && (cobrir || (temCobertos && agora - ultimaLimpa >= INTERVALO_LIMPA))
        cicloLimpo = precisaLimpa || !temCaixas
        if (cicloLimpo) ultimaLimpa = agora

        if (precisaLimpa) {
            overlay?.alpha = 0f
            handler.postDelayed({ capturar() }, ATRASO_ESCONDER)
        } else {
            capturar()
        }
    }

    private fun capturar() {
        if (!ativo) {
            overlay?.alpha = 1f
            emCiclo = false
            return
        }
        try {
            takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : TakeScreenshotCallback {
                override fun onSuccess(captura: ScreenshotResult) {
                    val apagar: List<RectF> =
                        if (cicloLimpo) emptyList() else overlay?.retangulosAtuais() ?: emptyList()
                    overlay?.alpha = 1f
                    try {
                        worker.execute { processar(captura, apagar) }
                    } catch (e: Exception) {
                        emCiclo = false
                    }
                }

                override fun onFailure(codigo: Int) {
                    // Tela protegida (app de banco, vídeo com DRM...) ou captura rápida demais.
                    overlay?.alpha = 1f
                    lerSomenteNos(true)
                }
            })
        } catch (e: Exception) {
            overlay?.alpha = 1f
            lerSomenteNos(true)
        }
    }

    /** Caminho sem OCR: só os textos que os apps expõem para a acessibilidade. */
    private fun lerSomenteNos(falhou: Boolean) {
        cicloLimpo = true
        try {
            worker.execute {
                val nos = try {
                    coletarNos()
                } catch (e: Exception) {
                    null
                }
                val lista = nos?.map {
                    it.copy(fundo = corPadraoFundo(), corTexto = corPadraoTexto())
                }
                handler.post { terminarCiclo(lista, false, falhou) }
            }
        } catch (e: Exception) {
            emCiclo = false
        }
    }

    /** Roda na thread de trabalho: converte a captura, lê os textos e junta tudo. */
    private fun processar(captura: ScreenshotResult, apagar: List<RectF>) {
        var bmp: Bitmap? = null
        try {
            val buffer = captura.hardwareBuffer
            val hw = Bitmap.wrapHardwareBuffer(buffer, captura.colorSpace)
            bmp = hw?.copy(Bitmap.Config.ARGB_8888, true)
            hw?.recycle()
            buffer.close()
        } catch (e: Exception) {
            bmp = null
        }
        if (bmp == null) {
            handler.post { terminarCiclo(null, false, true) }
            return
        }

        val tela: Bitmap = bmp
        try {
            if (apagar.isNotEmpty()) LeitorOcr.apagar(tela, apagar)
            val l = leitor
            val mudou = l?.mudou(tela) ?: true
            if (!mudou) {
                // Tela idêntica à anterior: não precisa ler de novo.
                handler.post { terminarCiclo(null, true, false) }
                return
            }

            val nos = try {
                coletarNos() ?: emptyList()
            } catch (e: Exception) {
                emptyList()
            }
            val lidos = try {
                l?.ler(tela) ?: emptyList()
            } catch (e: Exception) {
                emptyList()
            }

            val lista = ArrayList<Deteccao>()
            for (n in nos) {
                val (fundo, cor) = LeitorOcr.cores(tela, n.rect)
                lista.add(n.copy(fundo = fundo, corTexto = cor))
            }
            // O OCR só entra onde a acessibilidade não enxergou texto (imagens, vídeos, jogos).
            for (d in lidos) {
                val r = RectF(d.rect)
                val jaCoberto = nos.any { cobertura(r, RectF(it.rect)) >= 0.5f }
                if (!jaCoberto) lista.add(d)
            }
            handler.post { terminarCiclo(lista, false, false) }
        } catch (e: Exception) {
            handler.post { terminarCiclo(null, false, true) }
        } finally {
            tela.recycle()
        }
    }

    private fun terminarCiclo(dets: List<Deteccao>?, estatica: Boolean, falhou: Boolean) {
        handler.removeCallbacks(rotinaVigia)
        emCiclo = false
        if (!ativo) return

        val agora = SystemClock.uptimeMillis()
        when {
            estatica -> {
                rastreador.manterVivas(agora)
                intervalo = minOf(intervalo * 2, INTERVALO_MAX)
            }
            dets != null -> {
                rastreador.atualizar(dets, agora, maxOf(TOLERANCIA_MIN, intervalo * 3), cicloLimpo)
                intervalo = if (falhou) minOf(maxOf(intervalo, 700L) * 2, INTERVALO_MAX) else INTERVALO_MIN
            }
            falhou -> intervalo = minOf(maxOf(intervalo, 700L) * 2, INTERVALO_MAX)
        }
        renderizar()

        // O próximo ciclo conta a partir do início do anterior, para não perder tempo à toa.
        val gasto = agora - inicioCiclo
        agendar(maxOf(0L, intervalo - gasto))
    }

    // ---------------------------------------------------------------- leitura dos textos "de verdade"

    /** Percorre a janela ativa e devolve os textos visíveis com suas posições. */
    private fun coletarNos(): List<Deteccao>? {
        val raiz = rootInActiveWindow ?: return null
        if (raiz.packageName?.toString() == packageName) return emptyList()

        val janela = Rect()
        raiz.getBoundsInScreen(janela)
        val saida = ArrayList<Deteccao>()
        var visitados = 0

        fun visitar(no: AccessibilityNodeInfo?, nivel: Int) {
            if (no == null || visitados >= MAX_NOS || nivel > MAX_NIVEL) return
            visitados++
            if (!no.isVisibleToUser) return

            val texto = no.text?.toString()?.trim()
            if (!texto.isNullOrEmpty()) {
                if (aproveitavel(no, texto)) {
                    val r = Rect()
                    no.getBoundsInScreen(r)
                    if (r.intersect(janela) && r.width() >= 12 && r.height() >= 12) {
                        saida.add(Deteccao(r, texto))
                    }
                }
                return
            }
            for (i in 0 until no.childCount) visitar(no.getChild(i), nivel + 1)
        }

        visitar(raiz, 0)
        return saida
    }

    private fun aproveitavel(no: AccessibilityNodeInfo, texto: String): Boolean {
        if (no.isPassword || no.isEditable) return false
        if (texto.length > MAX_CHARS) return false
        if (texto.count { it.isLetter() } < 2) return false
        val semEspaco = texto.none { it.isWhitespace() }
        if (semEspaco && (texto.contains("://") || texto.contains('@') || texto.startsWith("www."))) {
            return false
        }
        return true
    }

    // ---------------------------------------------------------------- tradução e desenho

    private fun noite() =
        (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
            Configuration.UI_MODE_NIGHT_YES

    private fun corPadraoFundo() = if (noite()) 0xF01E1F22.toInt() else 0xF2FFFFFF.toInt()
    private fun corPadraoTexto() = if (noite()) 0xFFE8EAED.toInt() else 0xFF202124.toInt()

    private fun renderizar() {
        val tela = overlay ?: return
        val m = motor ?: return

        for (f in rastreador.lista) {
            val t = m.consultar(f.texto, f.ocr)
            if (t == null) {
                m.pedir(f.texto, f.ocr) { agendarRender() }
            } else {
                f.traducao = t
            }
        }

        val metricas = resources.displayMetrics
        val dens = metricas.density
        val larg = metricas.widthPixels.toFloat()
        val alt = metricas.heightPixels.toFloat()
        val todas = rastreador.lista
        val ocupados = ArrayList<RectF>()
        val caixas = ArrayList<OverlayView.Caixa>()

        for (f in todas.sortedBy { it.rect.top }) {
            val t = f.traducao
            if (t.isNullOrEmpty()) continue

            var caixa = RectF(f.rect)
            var maxSp = 44f
            f.cobrindo = false
            // Texto lido por OCR: a tradução vai ao lado (acima ou abaixo), sem esconder o
            // original, para o texto continuar sendo visto e acompanhado sem piscar.
            if (f.ocr && !cobrir) {
                val lado = posicionarAoLado(tela, f, t, todas, ocupados, dens, larg, alt)
                if (lado != null) {
                    caixa = lado.first
                    maxSp = lado.second
                } else {
                    f.cobrindo = true
                }
            }
            ocupados.add(caixa)
            caixas.add(
                OverlayView.Caixa(f.id, caixa, f.vx, f.vy, f.visto, t, f.fundo, f.corTexto, maxSp)
            )
        }
        tela.definir(caixas)
    }

    /** Acha um espaço livre acima ou abaixo do texto. Devolve (caixa, tamanho máximo da fonte). */
    private fun posicionarAoLado(
        tela: OverlayView, f: Faixa, texto: String, todas: List<Faixa>,
        ocupados: List<RectF>, dens: Float, larg: Float, alt: Float
    ): Pair<RectF, Float>? {
        val maxSp = (f.rect.height() / dens * 0.55f).coerceIn(10f, 20f)
        val w = f.rect.width().coerceIn(160f * dens, larg - 16f * dens)
        val h = tela.medir(texto, w.toInt(), maxSp)[1].toFloat()
        val folga = 2f * dens
        val borda = 4f * dens

        var esq = f.rect.left
        if (esq + w > larg - borda) esq = larg - borda - w
        if (esq < borda) esq = borda

        val cima = RectF(esq, f.rect.top - folga - h, esq + w, f.rect.top - folga)
        val baixo = RectF(esq, f.rect.bottom + folga, esq + w, f.rect.bottom + folga + h)
        for (c in listOf(cima, baixo)) {
            if (c.top < 0f || c.bottom > alt) continue
            if (espacoLivre(c, f, todas, ocupados)) return Pair(c, maxSp)
        }
        return null
    }

    private fun espacoLivre(c: RectF, dono: Faixa, todas: List<Faixa>, ocupados: List<RectF>): Boolean {
        for (o in todas) {
            if (o !== dono && RectF.intersects(c, o.rect)) return false
        }
        for (o in ocupados) {
            if (RectF.intersects(c, o)) return false
        }
        return true
    }

    private fun agendarRender() {
        if (!ativo) return
        handler.removeCallbacks(rotinaRender)
        handler.postDelayed(rotinaRender, 60L)
    }

    // ---------------------------------------------------------------- overlay

    private fun mostrarOverlay() {
        if (overlay != null) return
        val view = OverlayView(this)
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP or Gravity.START
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            params.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        try {
            // Importante: o WindowManager precisa vir do próprio serviço (this).
            (getSystemService(Context.WINDOW_SERVICE) as WindowManager).addView(view, params)
            overlay = view
        } catch (e: Exception) {
            overlay = null
        }
    }

    private fun removerOverlay() {
        val view = overlay ?: return
        overlay = null
        try {
            (getSystemService(Context.WINDOW_SERVICE) as WindowManager).removeView(view)
        } catch (e: Exception) {
            // já foi removido
        }
    }
}
