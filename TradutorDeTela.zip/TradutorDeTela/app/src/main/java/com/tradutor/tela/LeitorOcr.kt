package com.tradutor.tela

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizer
import com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions
import com.google.mlkit.vision.text.devanagari.DevanagariTextRecognizerOptions
import com.google.mlkit.vision.text.japanese.JapaneseTextRecognizerOptions
import com.google.mlkit.vision.text.korean.KoreanTextRecognizerOptions
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlin.math.abs

/**
 * OCR no aparelho (ML Kit): lê o texto que aparece em imagens, vídeos e jogos.
 * Deve ser chamado sempre fora da thread principal.
 */
class LeitorOcr {

    companion object {
        private const val LADO_MAX = 2400

        /**
         * Apaga da captura as caixas de tradução que o próprio app desenhou (pintando com a cor
         * ao redor), para o OCR não ler a tradução como se fosse texto da tela.
         */
        fun apagar(bmp: Bitmap, caixas: List<RectF>) {
            val canvas = Canvas(bmp)
            val pincel = Paint()
            for (c in caixas) {
                val r = Rect(
                    c.left.toInt() - 6, c.top.toInt() - 4,
                    c.right.toInt() + 6, c.bottom.toInt() + 4
                )
                if (!r.intersect(0, 0, bmp.width, bmp.height)) continue
                val (cor, _) = cores(bmp, r)
                pincel.color = cor or 0xFF000000.toInt()
                canvas.drawRect(r, pincel)
            }
        }

        /**
         * Descobre a cor de fundo ao redor do texto (para a caixa da tradução imitar o original)
         * e escolhe preto ou branco para o texto. Retorna (corDeFundo, corDoTexto).
         */
        fun cores(bmp: Bitmap, r: Rect): Pair<Int, Int> {
            val pontos = ArrayList<IntArray>()
            val m = 3
            val passos = 8
            for (i in 0..passos) {
                val x = r.left + r.width() * i / passos
                pontos.add(intArrayOf(x, r.top - m))
                pontos.add(intArrayOf(x, r.bottom + m))
            }
            for (i in 1..3) {
                val y = r.top + r.height() * i / 4
                pontos.add(intArrayOf(r.left - m, y))
                pontos.add(intArrayOf(r.right + m, y))
            }

            var somaR = 0
            var somaG = 0
            var somaB = 0
            var lumMin = 255
            var lumMax = 0
            for (p in pontos) {
                val px = bmp.getPixel(p[0].coerceIn(0, bmp.width - 1), p[1].coerceIn(0, bmp.height - 1))
                val cr = Color.red(px)
                val cg = Color.green(px)
                val cb = Color.blue(px)
                somaR += cr
                somaG += cg
                somaB += cb
                val l = (cr * 299 + cg * 587 + cb * 114) / 1000
                if (l < lumMin) lumMin = l
                if (l > lumMax) lumMax = l
            }
            val n = pontos.size
            val mr = somaR / n
            val mg = somaG / n
            val mb = somaB / n

            // Fundo muito variado (cena de vídeo): usa caixa escura estilo legenda.
            if (lumMax - lumMin > 90) {
                return Pair(0xE6000000.toInt(), 0xFFFFFFFF.toInt())
            }
            val lum = (mr * 299 + mg * 587 + mb * 114) / 1000
            val texto = if (lum < 140) 0xFFF5F5F5.toInt() else 0xFF161616.toInt()
            return Pair(Color.argb(0xF4, mr, mg, mb), texto)
        }
    }

    private class Cand(val rect: Rect, val texto: String, val letras: Int)

    // O alfabeto latino (inglês, espanhol, francês, alemão...) está sempre ligado.
    private val latim: TextRecognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    private val extras = LinkedHashMap<String, TextRecognizer>()
    private var assinatura: IntArray? = null
    private val espacos = Regex("\\s+")

    @Synchronized
    fun configurar(idiomas: Set<String>) {
        val fora = extras.keys.filter { it !in idiomas }
        for (k in fora) extras.remove(k)?.close()
        for (k in idiomas) {
            if (k in extras) continue
            val r = criar(k) ?: continue
            extras[k] = r
        }
    }

    private fun criar(codigo: String): TextRecognizer? = when (codigo) {
        "ja" -> TextRecognition.getClient(JapaneseTextRecognizerOptions.Builder().build())
        "zh" -> TextRecognition.getClient(ChineseTextRecognizerOptions.Builder().build())
        "ko" -> TextRecognition.getClient(KoreanTextRecognizerOptions.Builder().build())
        "hi" -> TextRecognition.getClient(DevanagariTextRecognizerOptions.Builder().build())
        else -> null
    }

    @Synchronized
    fun esquecer() {
        assinatura = null
    }

    @Synchronized
    fun fechar() {
        latim.close()
        for (r in extras.values) r.close()
        extras.clear()
    }

    /**
     * Compara a tela com a leitura anterior. Se quase nada mudou, não vale a pena
     * refazer o OCR (economiza bateria quando a tela está parada).
     */
    @Synchronized
    fun mudou(bmp: Bitmap): Boolean {
        val w = 72
        val h = 128
        val pequeno = Bitmap.createScaledBitmap(bmp, w, h, true)
        val atual = IntArray(w * h)
        pequeno.getPixels(atual, 0, w, 0, 0, w, h)
        if (pequeno !== bmp) pequeno.recycle()

        val anterior = assinatura
        assinatura = atual
        if (anterior == null || anterior.size != atual.size) return true

        var diferentes = 0
        for (i in atual.indices) {
            if (abs(luz(atual[i]) - luz(anterior[i])) > 20) diferentes++
        }
        return diferentes >= 6
    }

    private fun luz(p: Int): Int =
        (Color.red(p) * 299 + Color.green(p) * 587 + Color.blue(p) * 114) / 1000

    @Synchronized
    fun ler(bmp: Bitmap): List<Deteccao> {
        val maior = maxOf(bmp.width, bmp.height)
        val escala = if (maior > LADO_MAX) LADO_MAX.toFloat() / maior else 1f
        val entrada = if (escala < 1f) {
            Bitmap.createScaledBitmap(
                bmp, (bmp.width * escala).toInt(), (bmp.height * escala).toInt(), true
            )
        } else {
            bmp
        }
        val imagem = InputImage.fromBitmap(entrada, 0)

        val candidatos = ArrayList<Cand>()
        val reconhecedores = ArrayList<TextRecognizer>()
        reconhecedores.add(latim)
        reconhecedores.addAll(extras.values)

        for (r in reconhecedores) {
            val resultado = try {
                Tasks.await(r.process(imagem))
            } catch (e: Exception) {
                continue
            }
            for (bloco in resultado.textBlocks) {
                val caixa = bloco.boundingBox ?: continue
                val texto = limpar(bloco.text) ?: continue
                val rect = Rect(
                    (caixa.left / escala).toInt(),
                    (caixa.top / escala).toInt(),
                    (caixa.right / escala).toInt(),
                    (caixa.bottom / escala).toInt()
                )
                if (rect.width() < 14 || rect.height() < 12) continue
                // Folga para a caixa da tradução cobrir bem o texto original.
                val px = maxOf(4, rect.height() / 6)
                val py = maxOf(3, rect.height() / 10)
                rect.inset(-px, -py)
                rect.intersect(0, 0, bmp.width, bmp.height)
                candidatos.add(Cand(rect, texto, texto.count { it.isLetter() }))
            }
        }
        if (entrada !== bmp) entrada.recycle()

        // Se mais de um alfabeto leu o mesmo lugar, fica com a leitura que achou mais letras.
        val finais = ArrayList<Cand>()
        for (c in candidatos) {
            val a = RectF(c.rect)
            val i = finais.indexOfFirst {
                val b = RectF(it.rect)
                cobertura(a, b) > 0.5f || cobertura(b, a) > 0.5f
            }
            if (i < 0) {
                finais.add(c)
            } else if (c.letras > finais[i].letras * 1.2f) {
                finais[i] = c
            }
        }

        val saida = ArrayList<Deteccao>(finais.size)
        for (c in finais) {
            val (fundo, corTexto) = cores(bmp, c.rect)
            saida.add(Deteccao(c.rect, c.texto, fundo, corTexto, true))
        }
        return saida
    }

    private fun limpar(bruto: String): String? {
        val t = bruto.replace('\n', ' ').replace(espacos, " ").trim()
        if (t.isEmpty() || t.length > 600) return null
        val letras = t.count { it.isLetter() }
        if (letras < 2) return null
        val visiveis = t.count { !it.isWhitespace() }
        if (letras.toFloat() / visiveis < 0.55f) return null
        return t
    }
}
