package com.tradutor.tela

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.os.SystemClock
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.util.TypedValue
import android.view.View
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.min

/**
 * Camada transparente que desenha a tradução por cima do texto original.
 * As caixas deslizam suavemente até a posição do texto e, entre uma leitura e outra,
 * continuam andando na velocidade que o texto tinha (para acompanhar rolagem e movimento).
 */
class OverlayView(context: Context) : View(context) {

    /** Uma tradução a desenhar. [rect] é onde o texto estava em [quando]. */
    class Caixa(
        val id: Long,
        val rect: RectF,
        val vx: Float,
        val vy: Float,
        val quando: Long,
        val texto: String,
        val fundo: Int,
        val corTexto: Int,
        val maxSp: Float = 44f
    )

    private class Item(var caixa: Caixa, val atual: RectF) {
        var layout: StaticLayout? = null
        var layoutLargura = -1f
        var layoutAltura = -1f
        var layoutTexto = ""
        var extra = 0f
        var centralizar = false
    }

    companion object {
        private const val EXTRAPOLAR_MAX = 700L
        private const val SUAVIDADE_MS = 55f
    }

    private var itens = HashMap<Long, Item>()

    private val fundoPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val posicao = IntArray(2)
    private val caixaDesenho = RectF()
    private val margem = dp(4f)
    private val raio = dp(4f)

    private var animando = false
    private var ultimoQuadro = 0L
    private val quadro = Runnable { passo() }

    init {
        importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
    }

    private fun dp(v: Float) =
        TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, resources.displayMetrics)

    private fun sp(v: Float) =
        TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, v, resources.displayMetrics)

    fun temCaixas(): Boolean = itens.isNotEmpty()

    /** Onde as caixas estão desenhadas agora (coordenadas da tela). */
    fun retangulosAtuais(): List<RectF> =
        itens.values.map { RectF(it.atual.left, it.atual.top, it.atual.right, it.atual.bottom + it.extra) }

    private val cacheMedidas = HashMap<String, IntArray>()

    /** Mede a caixa [largura, altura] que a tradução precisa (no máximo 3 linhas). */
    fun medir(texto: String, largura: Int, maxSp: Float): IntArray {
        val chave = "$largura|${maxSp.toInt()}|$texto"
        cacheMedidas[chave]?.let { return it }
        val util = largura - (2 * margem).toInt()
        var tam = maxSp.toInt().coerceAtLeast(9)
        var layout = criarLayout(texto, sp(tam.toFloat()), util, 0)
        while (layout.lineCount > 3 && tam > 9) {
            tam--
            layout = criarLayout(texto, sp(tam.toFloat()), util, 0)
        }
        val r = intArrayOf(largura, layout.height + (2 * margem).toInt())
        if (cacheMedidas.size > 300) cacheMedidas.clear()
        cacheMedidas[chave] = r
        return r
    }

    fun definir(lista: List<Caixa>) {
        val agora = SystemClock.uptimeMillis()
        val novos = HashMap<Long, Item>()
        for (c in lista) {
            val antigo = itens[c.id]
            val item = if (antigo != null) {
                antigo.caixa = c
                antigo
            } else {
                Item(c, previsto(c, agora))
            }
            ajustarLayout(item)
            novos[c.id] = item
        }
        itens = novos
        invalidate()
        iniciarAnimacao()
    }

    private fun previsto(c: Caixa, agora: Long): RectF {
        val dt = min(agora - c.quando, EXTRAPOLAR_MAX).coerceAtLeast(0L) / 1000f
        val r = RectF(c.rect)
        r.offset(c.vx * dt, c.vy * dt)
        return r
    }

    // ---------------------------------------------------------------- animação

    private fun iniciarAnimacao() {
        if (animando || itens.isEmpty() || !isAttachedToWindow) return
        animando = true
        ultimoQuadro = SystemClock.uptimeMillis()
        postOnAnimation(quadro)
    }

    private fun passo() {
        val agora = SystemClock.uptimeMillis()
        val dt = (agora - ultimoQuadro).coerceIn(1L, 100L)
        ultimoQuadro = agora
        val k = 1f - exp(-dt / SUAVIDADE_MS)

        var mexendo = false
        for (item in itens.values) {
            val alvo = previsto(item.caixa, agora)
            val a = item.atual
            val dist = abs(alvo.left - a.left) + abs(alvo.top - a.top) +
                abs(alvo.right - a.right) + abs(alvo.bottom - a.bottom)
            if (dist > 0.6f) {
                a.left += (alvo.left - a.left) * k
                a.top += (alvo.top - a.top) * k
                a.right += (alvo.right - a.right) * k
                a.bottom += (alvo.bottom - a.bottom) * k
                mexendo = true
            } else {
                a.set(alvo)
            }
            val c = item.caixa
            val andando = (c.vx != 0f || c.vy != 0f) && agora - c.quando < EXTRAPOLAR_MAX
            if (andando) mexendo = true
        }
        invalidate()

        if (mexendo && itens.isNotEmpty() && isAttachedToWindow) {
            postOnAnimation(quadro)
        } else {
            animando = false
        }
    }

    override fun onDetachedFromWindow() {
        removeCallbacks(quadro)
        animando = false
        super.onDetachedFromWindow()
    }

    // ---------------------------------------------------------------- texto

    /** Escolhe o maior tamanho de fonte (8 sp até o máximo da caixa) em que a tradução cabe na caixa. */
    private fun ajustarLayout(item: Item) {
        val c = item.caixa
        val w = c.rect.width()
        val h = c.rect.height()
        if (item.layout != null && item.layoutTexto == c.texto &&
            abs(item.layoutLargura - w) <= 3f && abs(item.layoutAltura - h) <= 3f
        ) return

        val largura = (w - 2 * margem).toInt()
        val altura = (h - 2 * margem).toInt()
        if (largura < 10) {
            item.layout = null
            return
        }

        var menor = 8
        var maior = c.maxSp.toInt()
        var melhor: StaticLayout? = null
        while (menor <= maior) {
            val meio = (menor + maior) / 2
            val l = criarLayout(c.texto, sp(meio.toFloat()), largura, c.corTexto)
            if (l.height <= altura) {
                melhor = l
                menor = meio + 1
            } else {
                maior = meio - 1
            }
        }

        if (melhor != null) {
            item.layout = melhor
            item.extra = 0f
        } else {
            // Não coube nem no menor tamanho: a caixa cresce para baixo em vez de cortar o texto.
            val l = criarLayout(c.texto, sp(9f), largura, c.corTexto)
            item.layout = l
            item.extra = maxOf(0f, l.height + 2 * margem - h)
        }
        item.centralizar = item.layout!!.lineCount == 1
        item.layoutTexto = c.texto
        item.layoutLargura = w
        item.layoutAltura = h
    }

    private fun criarLayout(texto: String, tamanho: Float, largura: Int, cor: Int): StaticLayout {
        // Um TextPaint por layout: o StaticLayout guarda a referência do pincel.
        val pincel = TextPaint(Paint.ANTI_ALIAS_FLAG)
        pincel.textSize = tamanho
        pincel.color = cor
        return StaticLayout.Builder.obtain(texto, 0, texto.length, pincel, largura)
            .setAlignment(Layout.Alignment.ALIGN_NORMAL)
            .setIncludePad(false)
            .build()
    }

    override fun onDraw(canvas: Canvas) {
        if (itens.isEmpty()) return

        // Converte coordenadas da tela para as desta janela.
        getLocationOnScreen(posicao)

        for (item in itens.values) {
            val layout = item.layout ?: continue
            val a = item.atual
            val esq = a.left - posicao[0]
            val topo = a.top - posicao[1]
            caixaDesenho.set(esq, topo, esq + a.width(), topo + a.height() + item.extra)

            fundoPaint.color = item.caixa.fundo
            canvas.drawRoundRect(caixaDesenho, raio, raio, fundoPaint)

            val deslocY = if (item.centralizar && item.extra == 0f) {
                (a.height() - layout.height) / 2f
            } else {
                margem
            }

            canvas.save()
            canvas.clipRect(caixaDesenho)
            canvas.translate(esq + margem, topo + deslocY)
            layout.draw(canvas)
            canvas.restore()
        }
    }
}
